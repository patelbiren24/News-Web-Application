import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  api: string = 'http://localhost:5000/api/user';

  subject: Subject<string> = new Subject<string>();

  constructor(private httpClient: HttpClient) {}

  getUserDetails(email: string): Observable<any> {
    return this.httpClient.get(this.api + '?email=' + email);
  }

  getNews(): Observable<any> {
    return this.httpClient.get(this.api + '/news');
  }
  deleteNews(id: any): Observable<any> {
    const token = localStorage.getItem('token');
    return this.httpClient.delete(this.api + '/delete?id=' + id, {
      headers: {
        Authorization: 'Bearer ' + token,
      },
    });
  }
  createUser(register: any): Observable<any> {
    return this.httpClient.post(this.api + '/register', register);
  }

  editNews(id: any, updatedItem: any){
    const token = localStorage.getItem('token');
    return this.httpClient.post(this.api + '/edit/' + id, updatedItem, {
      headers: {
        Authorization: 'Bearer ' + token,
      },
    });
  }

  login(login: any): Observable<any> {
    return this.httpClient.post(this.api + '/login', login);
  }


  addNews(news: any): Observable<any> {
    console.log('in add news function');
    const token = localStorage.getItem('token');
    return this.httpClient.post(this.api + '/add', news, {
      headers: {
        Authorization: 'Bearer ' + token,
      },
    });
  }

  getWeather(): Observable<any>{
    return this.httpClient.get(this.api + '/weather');
  }

  getSportsNews(): Observable<any> {
    return this.httpClient.get(this.api + '/sports');
  }
}
