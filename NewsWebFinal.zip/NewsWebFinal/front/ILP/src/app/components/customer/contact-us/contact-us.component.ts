import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css'],
})
export class ContactUsComponent implements OnInit {
  constructor() {}

  name: string;
  email: string;
  subject: string;
  message: string;

  ngOnInit(): void {}
  submit() {
    alert(
      'Your Query has been submitted and we will get back to you with a response. Thank You'
    );
    this.name = '';
    this.email = '';
    this.subject = '';
    this.message = '';
  }
}
