import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-sports',
  templateUrl: './sports.component.html',
  styleUrls: ['./sports.component.css']
})
export class SportsComponent implements OnInit {

  sports: any = [];
  constructor(private service: AuthService) { }

  ngOnInit(): void {
    this.service.getSportsNews().subscribe(item => {
      this.sports = item.news;
      console.log(item.news)
    });
    // this.service.getNews().subscribe((res) => {
    //   this.sports = res;
    // });
  }

}
