import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {AuthService} from 'src/app/services/auth.service';

@Component({
  selector: 'app-add-news',
  templateUrl: './add-news.component.html',
  styleUrls: ['./add-news.component.css']
})
export class AddNewsComponent implements OnInit {
  news:any = {
    "title":'',
    "description":'',
    "publishedAt":Date,
    "imageUrl":'',
    "newsType":''
  };
  date:Date = new Date();
  constructor(private authService:AuthService, private route: Router) { }

  ngOnInit(): void {
  }
  newsSubmit() {
    this.news.publishedAt = this.date
    console.log("out of ")
    this.authService.addNews(this.news).subscribe((res)=>{
      console.log("asd")
      console.log(JSON.stringify(res));
      alert("News Added!")
      this.route.navigate(['admin/edit-news']);

    })
    console.log("after")
    console.log(JSON.stringify(this.news));


  }
  resetSubmit(){
    this.news = {}
  }

}
