import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-edit-news',
  templateUrl: './edit-news.component.html',
  styleUrls: ['./edit-news.component.css'],
})
export class EditNewsComponent implements AfterViewInit {
  news: any = [];
  title: string;
  description: string;
  publishedAt: string;
  id: any;

  edit(index) {
    this.news[index].showEdit = !this.news[index].showEdit;
    if (!this.news[index].showEdit) {
      let id = this.news[index]._id;
      let data = {
        title: this.news[index].title,
        description: this.news[index].description,
      };
      this.authService.editNews(id, data).subscribe((item) => {
        console.log(item);
      });
    }
  }

  delete(id) {
    console.log('Before suscribe', id);
    this.news = this.news.filter((news) => news._id !== id);
    this.authService.deleteNews(id).subscribe((item) => {
      console.log(item);
    });
  }

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.authService.getNews().subscribe((item) => {
      this.news = item.result;
      this.news.forEach((item) => {
        item.showEdit = false;
      });
      console.log(this.news);
    });
  }
  ngAfterViewInit() {
    //  this.dataSource.paginator = this.paginator;
    //  this.dataSource.sort = this.sort;
  }
}
