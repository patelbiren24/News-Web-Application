import { Component, OnInit } from '@angular/core';
import {AuthService} from 'src/app/services/auth.service'

@Component({
  selector: 'app-nav-bar-adm',
  templateUrl: './nav-bar-adm.component.html',
  styleUrls: ['./nav-bar-adm.component.css']
})
export class NavBarAdmComponent implements OnInit {
  data: string = '';
  constructor(private authService:AuthService) {}
  user :string = '';
  userDetails : []
  ngOnInit(): void {
    
  }

}
