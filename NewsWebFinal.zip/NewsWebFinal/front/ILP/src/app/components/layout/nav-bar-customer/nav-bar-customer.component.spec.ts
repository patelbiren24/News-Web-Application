import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavBarCustomerComponent } from './nav-bar-customer.component';

describe('NavBarCustomerComponent', () => {
  let component: NavBarCustomerComponent;
  let fixture: ComponentFixture<NavBarCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NavBarCustomerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NavBarCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
