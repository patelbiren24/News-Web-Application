import { Component, OnInit } from '@angular/core';
import {AuthService} from 'src/app/services/auth.service'

@Component({
  selector: 'app-nav-bar-customer',
  templateUrl: './nav-bar-customer.component.html',
  styleUrls: ['./nav-bar-customer.component.css']
})
export class NavBarCustomerComponent implements OnInit {
  data: string = '';
  constructor(private authService:AuthService) { }

  ngOnInit(): void {
    this.authService.subject.subscribe((res) => (this.data = res));
  }

}
