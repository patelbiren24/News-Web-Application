import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthService} from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  model: any = {};
  result: any = [];
  login:string;
  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit(): void {}

  handleSubmit(){
    this.authService.login(this.model).subscribe((res) => {
      console.log(res);
      console.log(JSON.stringify(res));
      if(res.msg === "Logged In successfully"){
        localStorage.setItem('token', res.token);
        this.authService.subject.next('loggedin');

        console.log(res.token)



        this.router.navigate(['/admin/add-news']);
        alert(res.msg)

      }
      else{
        console.log(res.msg);
        if (res.msg !=null){
          alert('Incorrect Password');
        }



      }

    }, (err) => {
      if (err){
        alert('Incorrect Password');
      }
    });

  }

}
