let a = {
  secret: "Top Secret",
};

module.exports = a;
