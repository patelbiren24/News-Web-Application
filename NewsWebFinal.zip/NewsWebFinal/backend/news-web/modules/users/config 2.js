let a = {
  secret: "topsecret",
};

module.exports = a;
